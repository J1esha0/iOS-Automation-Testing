//
//  UITests.swift
//  UITests
//
//  Created by Joe Masilotti on 9/7/15.
//  Copyright © 2015 Masilotti.com. All rights reserved.
//

import XCTest

class UITests: XCTestCase {
    
    let app = XCUIApplication()
    
    override func setUp() {
        super.setUp()
        app.launch()
    }

    override func tearDown() {
        super.tearDown()
    }
    
    func testexample(){
    //完成课上提到的所有测试
    app.staticTexts["View Schedule"].tap()
    app.buttons["Finish Game"].tap()
    app.alerts["You won!"].buttons["Awesome!"].tap()
    //app.buttons["Awesome!"].tap()
    //app.alerts.descendants(matching: .button).matching(identifier: "Awesome!").element.tap()
    app.buttons["Back"].tap()
    
    
    app.staticTexts["Manage Team"].tap()
    app.sliders.element.adjust(toNormalizedSliderPosition: 0.7)
    XCTAssert(app.staticTexts["7"].exists)
    app.buttons["Back"].tap()
    
    app.staticTexts["Manage Team"].tap()
    app.pickers.pickerWheels.matching(identifier: "Attackers Formation").element.adjust(toPickerWheelValue: "6 attackers")
    app.pickers.pickerWheels.matching(identifier: "Setters Formation").element.adjust(toPickerWheelValue: "1 setter")
    app.buttons["Back"].tap()
    
    app.buttons.matching(identifier: "More Info").element.tap()
    //dump(XCUIApplication())
    sleep(3);app.links["Volleyball (disambiguation)"].tap()
    app.links["Volleyball (ball)"].tap()
    app.buttons["Back"].tap()
        
    app.tables.cells.staticTexts.matching(identifier: "Manage Roster").element.tap()
    let brianbutton = app.tables.cells.buttons.matching(identifier: "Reorder Brian").element
    app.tables.cells.buttons.matching(identifier: "Reorder Joe").element.press(forDuration: 3, thenDragTo: brianbutton)
    app.buttons["Back"].tap()
        
    app.staticTexts["Manage Roster"].tap()
    let firstCell = app.staticTexts["Adrienne"]
    let coordinate = firstCell.coordinate(withNormalizedOffset: CGVector(dx: 0, dy: 0))
    let buttom = firstCell.coordinate(withNormalizedOffset: CGVector(dx: 0, dy: 6))
    coordinate.press(forDuration: 0, thenDragTo: buttom)
    app.buttons["Dismiss"].tap()
    app.buttons["Back"].tap()
        
    let predicate = NSPredicate(format: "label BEGINSWITH 'Set your team details'")
    let label = app.staticTexts.element(matching: predicate)
    XCTAssert(label.exists)
        
    let predicate1 = NSPredicate(format: "label ENDSWITH 'upcoming games.'")
    let label1 = app.staticTexts.element(matching: predicate1)
    XCTAssert(label1.exists)
        
    let predicate2 = NSPredicate(format: "label CONTAINS 'and view'")
    let label2 = app.staticTexts.element(matching: predicate2)
    XCTAssert(label2.exists)
        
    let setterPredicate = NSPredicate(format: "label BEGINSWITH 'Setters Formation'")
    let setterPicker = app.pickerWheels.element(matching: setterPredicate);setterPicker.adjust(toPickerWheelValue:"1 setter")
    
    app.staticTexts["View Schedule"].tap()
    app.buttons["Load More Games"].tap()
    let nextGame = self.app.staticTexts["Game 4 - Tomorrow"]
    let existsPredicate = NSPredicate(format: "exists == true");expectation(for: existsPredicate, evaluatedWith: nextGame, handler: nil)
    XCTAssert(nextGame.exists)
        
        
    }
}
